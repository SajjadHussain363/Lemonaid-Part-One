import React from "react";
import { Link } from 'react-router-dom'
import donereview from "../images/donereview.png";


const Paymentdonepopup = () => {
  return (
    <>
      <div>
      <div className="container mt-5">
    <div className="row">
      <div className="col-md-4 mx-auto">
        <div className="payment-done-check">
         <h3 className="review-payment-done text-center">Payment Done</h3>
         <div className="review-img text-center mt-5">
           <img  src={donereview} alt="donereview" />
         </div>
         <div className="text-center mt-5">
         <Link to="/review">
           <button className="payment-done-btn text-center">OK</button>
           </Link>
         </div>
       </div>
     </div>
   </div>
 </div>
      </div>
    </>
  );
};

export default Paymentdonepopup;
