import React from "react";
import card5 from "../images/card5.png";
import mastercard from "../images/mastercard.png";
import { Link } from "react-router-dom";
import Garage from "../garage/garage";
import Modal from "react-bootstrap/Modal";
import ReportPdf from '../report-pdf/report-pdf'
import VehicleInsepctionReportPop from '../vehicle-inspection-report-popup/vehicle-inspection-report-popup'
const UpComingServices = () => {
	const [type, setType] = React.useState("");
    const [cardNo, setCardNo] = React.useState(-1);
    const [modal2, setModal2] = React.useState(false);
    // const [sideBar, setSideBar] = React.useState(false);
  return (
    <div>
      <main className="">
        <div className="header_top" data-toggle="">
          <div className="container">
            <div className="row">
              <div className="col-md-9 p-0">
                <div className="left-side_heading_home">
                  <h1 className="Navs_headings">Inspection Info</h1>
                </div>
              </div>
              <div className="col-md-3 text-right p-0"></div>
            </div>
          </div>
        </div>

        <div className="container mt-5">
		<div className="upcomings_headings pb-4"><h3>Upcoming</h3></div>
		<div className="row">
			<div className="col-md-5">
				 {/* <button onClick={() => { setModal2(true) }} className="btn">Edit Payment Method</button> */}
				<div onClick={() => { setModal2(true) }} className="upcoming-services-wrapper">
					<h3><strong>Vehicle Inspection Report </strong></h3>
					<p>Fulton Street, New York</p>
					<p className="scheduled-on">Scheduled on</p>
					<p className="day-date-time">
						<strong>Thursday, 22nd June, 2020  <br />
						04:00 PM</strong>
					</p>
					<span className="upcoming-dollar-card-price">$198</span>
				</div>
			</div>
		</div>
		<div className="row mt-5">
			<div className="col-md-5">
			{/* <button onClick={() => { setType('main') }}>Next</button> */}
				<div onClick={() => { setType('main') }} className="past-services-wrapper">
					<h3><strong>Vehicle Inspection Report </strong></h3>
					<p className="scheduled-on">
						Quisque suscipit ipsum est, eu venenatis leo ornare eget. Ut porta facilisis elementum. Sed condimentum...
					</p>
					<p className="day-date-time">
						<strong>Fulton Street, New York</strong>
					</p>
					<span className="past-dollar-card-price">Report</span>
				</div>
			</div>
			<div className="col-md-5">
				<div className="past-services-wrapper">
					<h3><strong>Vehicle Inspection Report </strong></h3>
					<p className="scheduled-on">
						Quisque suscipit ipsum est, eu venenatis leo ornare eget. Ut porta facilisis elementum. Sed condimentum...
					</p>
					<p className="day-date-time">
						<strong>Fulton Street, New York</strong>
					</p>
					<span className="past-dollar-card-price">Report</span>
				</div>
			</div>
		</div>
		<div className="row mt-5">
			<div className="col-md-5">
				<div className="past-services-wrapper">
					<h3><strong>Vehicle Inspection Report </strong></h3>
					<p className="scheduled-on">
						Quisque suscipit ipsum est, eu venenatis leo ornare eget. Ut porta facilisis elementum. Sed condimentum...
					</p>
					<p className="day-date-time">
						<strong>Fulton Street, New York</strong>
					</p>
				</div>
			</div>
			<div className="col-md-5">
				<div className="past-services-wrapper">
					<h3><strong>Vehicle Inspection Report </strong></h3>
					<p className="scheduled-on">
						Quisque suscipit ipsum est, eu venenatis leo ornare eget. Ut porta facilisis elementum. Sed condimentum...
					</p>
					<p className="day-date-time">
						<strong>Fulton Street, New York</strong>
					</p>
				</div>
			</div>
		</div>
		<div className="row mt-5">
			<div className="col-md-5">
				<div className="past-services-wrapper">
					<h3><strong>Vehicle Inspection Report </strong></h3>
					<p className="scheduled-on">
						Quisque suscipit ipsum est, eu venenatis leo ornare eget. Ut porta facilisis elementum. Sed condimentum...
					</p>
					<p className="day-date-time">
						<strong>Fulton Street, New York</strong>
					</p>
				</div>
			</div>
			<div className="col-md-5">
				<div className="past-services-wrapper">
					<h3><strong>Vehicle Inspection Report </strong></h3>
					<p className="scheduled-on">
						Quisque suscipit ipsum est, eu venenatis leo ornare eget. Ut porta facilisis elementum. Sed condimentum...
					</p>
					<p className="day-date-time">
						<strong>Fulton Street, New York</strong>
					</p>
					<span className="past-dollar-card-price">Report</span>
				</div>
			</div>
		</div>

	</div>
      </main>
	  <Modal show={!!type} onHide={() => setType("")} centered >
                {type === "main" ? <VehicleInsepctionReportPop onSelect={() => setType("garage")} /> : type === "garage" ? <Garage /> : undefined}
            </Modal>
            <Modal show={modal2} onHide={() => setModal2(false)}  centered >
      <ReportPdf/>
      </Modal>
            {/* {sideBar ? <EditPayemtnRightSide /> : null} */}
    </div>
  );
};

export default UpComingServices;
