import React from "react";

const Address = () => {
  return (
  
      <div>
 <main className="">
    <div className="header_top header_address_top" data-toggle="">
      <div className="container">
        <div className="row">
          <div className="col-md-9 p-0">
            <div className="left-side_heading_home">
              <h1>Addresses</h1>
            </div>
          </div>
          <div className="col-md-3 text-right p-0">
           
          </div>
        </div>
      </div>
    </div>

    <div className="container">
      <div className="row">
        <div className="col-md-4">
          <div className="address-boxes-wrapper">
           <ul className="list-inline">
            <div className="address-boxes-inner">
             <li  className="list-inline-item fulton-li street-address">Fulton Street, New York  <br />
             <span>
               <small>Work</small>
               </span>
             </li>
             <li  className="list-inline-item ellips-dots">
               <i className="fa fa-ellipsis-v" aria-hidden="true"></i>
               </li>
           </div>
         </ul>
       </div>
     </div>
     <div className="col-md-4">
      <div className="address-boxes-wrapper">
       <ul className="list-inline">
        <div className="address-boxes-inner">
          <li  className="list-inline-item fulton-li fair-heaven">277, Fair Heaven Street, New York  <br /><span><small className="small-home">Home</small></span></li>
          <li  className="list-inline-item ellips-dots"><i className="fa fa-ellipsis-v" aria-hidden="true"></i></li>
        </div>
      </ul>
    </div>
  </div>
</div>  
<div className="row mt-5 margin_mobile_zero">
  <div className="col-md-4">
    <div className="address-boxes-wrapper">
     <ul className="list-inline">
      <div className="address-boxes-inner">
       <li  className="list-inline-item fulton-li barclay">Barclay Street, New York  <br /><span><small className="cmall-other">Other</small></span></li>
       <li  className="list-inline-item ellips-dots"><i className="fa fa-ellipsis-v" aria-hidden="true"></i></li>
     </div>
   </ul>
 </div>
</div>
<div className="col-md-4">
  <div className="address-boxes-wrapper">
   <ul className="list-inline">
    <div className="address-boxes-inner">
     <li  className="list-inline-item fulton-li nyc" >City Hall, Brooklyn Bridge, NYC  <br /><span><small className="others-samll">Other</small></span></li>
     <li  className="list-inline-item ellips-dots"><i className="fa fa-ellipsis-v" aria-hidden="true"></i></li>
   </div>
 </ul>
</div>
</div>
</div> 
</div>
</main>
      </div>
   
  );
};

export default Address;
