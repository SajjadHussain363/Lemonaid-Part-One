import React from "react";

const Settings = () => {
  return (
  
 <div>
     <main className="">
    <div className="header_top" data-toggle="">
      <div className="container">
        <div className="row">
          <div className="col-md-9 p-0">
            <div className="left-side_heading_home">
              <h1>Settings</h1>
            </div>
          </div>
          
        </div>
      </div>
    </div>
        <div className="container">
            <div className="row mt-5">
            <div className="col-md-12">
                <div className="Settings-wrapper">
                <p>Change Password</p>
                <p className="mt-5">Notifications</p>
                <p className="mt-5">Location Access</p>
                </div>
            </div>
            </div>
            
                <div className="row">
                <div className="col-md-12">
                    <div className="settings-footer-nav">
                    <ul className="list-inline">
                    <li className="list-inline-item">About</li>
                    <li className="list-inline-item">Report a Problem</li>
                    <li className="list-inline-item">Feedback</li>
                    <li className="list-inline-item">Help & Support</li>
                    <li className="list-inline-item">Privacy Policy</li>
                    <li className="list-inline-item">Terms and Conditions</li>
                    </ul>
                </div> 
                </div>
            </div>
            </div>
         </main>
      </div>
   
  );
};

export default Settings;
