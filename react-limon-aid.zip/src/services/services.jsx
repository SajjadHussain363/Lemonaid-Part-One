import React from "react";
import { Link } from 'react-router-dom'


const Services = () => {
  return (
    <>
      <div>
        <main className="">
          <div className="header_top" data-toggle="">
            <div className="container">
              <div className="row">
                <div className="col-md-9 p-0">
                  <div className="left-side_heading_home">
                    <h1>Services</h1>
                  </div>
                </div>
                <div className="col-md-3 text-right p-0">
                 
                </div>
              </div>
            </div>
          </div>
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="vehicle-inspection-report-heading">
                  <h3>Vehicle Inspection Report</h3>
                </div>
              </div>
              <div className="services-time-section mt-3">
                <ul className="list-inline">
                  <li className="list-inline-item"><strong><i class="fa fa-clock-o" aria-hidden="true"></i> &nbsp;45 mins</strong></li>
                  <li className="list-inline-item service-prices"><strong>$99</strong></li>
                </ul>
              </div>
            </div>
            <div className="row mt-3">
              <div className="enter-vin">
                <form className="form-group">
                  <label className="label-service-enter-vin">Enter VIN</label>
                  <div className="form-group col-sm-12">
                    <input
                      type="text"
                      id="rg-from"
                      name="rg-from"
                      placeholder="JT152EEA100302159"
                      className="form-control"
                    />
                  </div>
                  <div className="col-sm-12 or mt-4">
                    <span>Or</span>
                  </div>
                  <div className="col-sm-12 service-forms">
                    <div className="row">
                      <div className="form-group col-sm-6">
                        <label>Make</label>
                        <input
                          type="text"
                          className="form-control"
                          id="exampleInputText"
                          placeholder="Toyota"
                        />
                      </div>
                      <div className="form-group col-sm-6">
                        <label>Model</label>
                        <input
                          type="text"
                          className="form-control"
                          id="exampleInputText"
                          placeholder="Camry 2.4"
                        />
                      </div>
                    </div>
                    <div className="row">
                      <div className="form-group col-sm-6">
                        <label for="exampleInputNumber">Year</label>
                        <input
                          type="tel"
                          className="form-control"
                          id="exampleInputNumber"
                          placeholder="2018"
                        />
                      </div>
                      <div className="form-group col-sm-6">
                        <label>Miles</label>
                        <input
                          type="text"
                          className="form-control"
                          id="exampleInputNumber"
                          placeholder="60,000"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="row mt-5">
                    <div className="col-sm-12 next-service-btn">
                      <div className="text-right ml-auto" align="right">
                        <Link to="/inspectionInfo" >
                            <button type="button" className="btn next-btn">
                            Next
                            </button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </main>
      </div>
    </>
  );
};

export default Services;
