import React from "react";
import { Link } from "react-router-dom";

const VehicleInspectionReport = (props) => {
  return (
    <>
      <div>
        <div className="">
          <div className="">
            <div className="">
              <div className="vehicle-inspection-report-wrapper">
                <h3 className="vehicle-inspection-report-heading text-center">
                  Vehicle Inspection Report
                </h3>
                <div className="price_time_vehicle mt-3 text-center">
                  <ul className="list-inline">
                    <li className="list-inline-item furty-five">45 mins</li>
                    <li className="list-inline-item ">
                      <strong>$99</strong>
                    </li>
                  </ul>
                </div>
                <div className="select-from-garage-wrapper mt-5">
                  <ul className="list-inline text-center">
                    <li
                      className="list-inline-item select-from-garage-inner"
                      onClick={props.onSelect}
                    >
                      Select from Garage
                    </li>
                    <Link to="/services">
                      <li className="list-inline-item add-new-car">
                        Add New Car
                      </li>
                    </Link>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default VehicleInspectionReport;
