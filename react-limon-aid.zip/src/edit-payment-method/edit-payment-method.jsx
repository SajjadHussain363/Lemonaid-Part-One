import React from "react";
import Modal from "react-bootstrap/Modal";
import { Link } from 'react-router-dom'
import visa1 from "../images/visa1.png";
import buket from "../images/buket.png";
import buketd from "../images/buketd.png";
import Paymentdonepopup from "../PaymentDoneCheck/paymentdonecheck";
import Garage from "../garage/garage";


const PaymentEditMethod = () => {
 
  return (
    <>
      <div>
      <p>THis IS payment edit page</p>
      </div>
     
    </>
  );
};

export default PaymentEditMethod;
