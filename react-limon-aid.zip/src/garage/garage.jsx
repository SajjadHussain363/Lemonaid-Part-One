import React from "react";
import car1 from "../images/car1.png";
import car2 from "../images/car2.png";

const Garage = () => {
  return (
  
<div>

  <div className="header_top" data-toggle="">
      <div className="container">
          <div className="row">
              <div className="col-md-9 p-0">
                  <div className="left-side_heading_home">
                      <h1 className="setting-heading">Garage</h1>
                  </div>
              </div>
          </div>
      </div>
  </div>
<div className="container">
  <div className="row">
   <div className="col-lg-4 col-md-12">
     <div className="garage-car-box">
       <img  src={car1} alt="car1" />
       <div className="car-text">
         <h3 className="Toyota_camry_">Toyota Camry 2.4</h3>
          <small className="Toyota_camry_small">60,000 miles</small>
       </div>
     </div>
   </div>
   <div className="col-lg-4 col-md-12">
     <div className="garage-car-box">
       <img  src={car2} alt="car1" />
       <div className="car-text">
         <h3 className="Toyota_camry_">Toyota Camry 2.4</h3>
          <small  className="Toyota_camry_small">60,000 miles</small>
       </div>
     </div>
   </div>
  </div> 
</div>

    
</div>
   
  );
};

export default Garage;
