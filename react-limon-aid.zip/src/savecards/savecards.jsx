import React from "react";
import visa1 from "../images/visa1.png";
import mastercard from "../images/mastercard.png";
    import { Link } from 'react-router-dom'


const SaveCard = () => {
  return (
  
<div>
   <main className="">
    <div className="header_top" data-toggle="">
        <div className="container">
            <div className="row">
                <div className="col-lg-9 col-md-12 p-0">
                    <div className="left-side_heading_home">
                        <h1 className="Navs_headings">Cards</h1>
                    </div>
                </div>
                <div className="col-lg-3 col-md-12">
                    <div className="add-payment-method">
                        <Link to="/loginregister">
                            <button type="button">
                            Add Payment Method
                            </button>
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div className="container">
        <div className="row">
            <div className="col-lg-4 col-md-12">
                <div className="cards-save-wrapper">
                    <h3>John Doe <span className="trashbuket">
                        <i className="fa fa-trash-o" aria-hidden="true"></i>
                        </span>
                    </h3> 
                    <p>#### - #### - #### - 2134</p>
                    <div className="text-right"><img src={visa1} alt="visa1"  /></div>
                </div>
            </div>
        </div>
        <div className="row mt-5">
            <div className="col-lg-4 col-md-12">
                <div className="cards-save-wrapper">
                    <h3>John Doe 
                        <span className="trashbuket">
                        <i className="fa fa-trash-o" aria-hidden="true"></i>
                        </span>
                    </h3> 
                    <p>#### - #### - #### - 2134</p>
                    <div className="text-right"><img src={mastercard} alt="mastercard"  /></div>
                </div>
            </div>
        </div>
    </div>
    </main>
</div>
   
  );
};

export default SaveCard;
