import React from "react";
import Modal from "react-bootstrap/Modal";
import Garage from "../garage/garage";


const EditPayemtnRightSide = () => {
 
  return (
    <>
      <div>
      <div className="card">
    <div className="container">
        <div className="row">
            <div className="col-lg-6">
                <div className="right-section-payment-method">
                    <div className="payment-method-cards-save-wrapper">
                            <h3>John Doe <span>
                                <img src="images/buket2.png" alt="buket del" />
                            </span></h3> 
                            <p>#### - #### - #### - 2134</p>
                            <div className="text-right"><img src="images/visa1.png" /></div>
                        </div>
                        <hr />
                        <div className="payment-cards-three">
                            <ul className="list-inline text-center">
                               <li className="list-inline-item"><img src="images/visa1.png" alt="logo brand" /></li>
                               <li className="list-inline-item"><img src="images/mastercard.png" alt="logo brand" /></li>
                               <li className="list-inline-item"><img src="images/paypal.png" alt="logo brand" /></li>
                           </ul>
                        </div>
                        <div className="form-paymethod">
                            <div className="row">
                                <div className="col-sm-12">
                                    <div className="form-group ">
                                    <label className="control-label m-0" for="email"><small>Card holder's name</small></label>
                                    <div className="input-group payment_custom_inputs">
                                        <input className="form-control" id="email" name="email" placeholder="John Doe" type="text"/>
                                    <div className="input-group-addon">
                                        <i className="fa fa-check" aria-hidden="true"></i>
                                    </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                             <div className="row">
                                <div className="col-sm-6">
                                    <div className="form-group ">
                                    <label className="control-label m-0" for="email"><small>Expiration Date</small></label>
                                    <div className="input-group payment_custom_inputs">
                                        <input className="form-control" id="email" name="email" placeholder="09/22" type="text"/>
                                    <div className="input-group-addon">
                                        <i className="fa fa-check" aria-hidden="true"></i>
                                    </div>
                                    </div>
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group ">
                                    <label className="control-label m-0" for="email"><small>CVV</small></label>
                                    <div className="input-group payment_custom_inputs">
                                        <input className="form-control" id="email" name="email" placeholder="•••" type="text"/>
                                    <div className="input-group-addon">
                                        <i className="fa fa-check" aria-hidden="true"></i>
                                    </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-4">
                                <div className="col-sm-12 text-center">
                                    <div className="add-payment-method">
                                        <button>Add Payment Method</button>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-4">
                                <div className="col-sm-12 text-center">
                                    <div className="add-payment-method-discard">
                                        <button>Discard</button>
                                    </div>
                                </div>
                            </div>
                        </div>
            </div>
        </div>
    </div>

</div>
      </div>
      </div>
     
    </>
  );
};

export default EditPayemtnRightSide;
