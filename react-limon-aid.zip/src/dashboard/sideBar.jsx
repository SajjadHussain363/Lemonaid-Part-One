import React, { useState } from 'react';
import { Link } from 'react-router-dom'
import './sideBar.css'
import user from '../images/user.jpeg'
import {
    isMobile
} from "react-device-detect";
const SideBar = () => {
    const [open, setOpen] = useState(isMobile ? false : true);
    return (
        <div className="app sidebar-mini">

            <header className="">

            </header>

            <div className="top_toggle_btn_wrapper" onClick={() => {
                // console.log("Mobile")
                setOpen((pre) => !pre)

            }}>
                <a className="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
            </div>

            <aside className="app-sidebar" style={open ? { left: "-0px", transition: "all 0.5s ease 0s;" } : { left: "-300px", transition: "all 0.5s ease 0s;"  }}>
                <div className="user_wrapper text-center">
                    <a href="app-menu__item">
                        <img src={user} style={{ width: 120, height: 120, borderRadius: "100%" }} />
                    </a>
                    <div className="admin_name text-center pt-4 pb-4"><h3 className="text-center">John Doe</h3></div>
                </div>
                <ul className="app-menu">
          <li>
            <Link to="/" className="app-menu__item">
              <span className="app-menu__label">Home</span>
            </Link>
          </li>
          <li>
            <Link to="/upcomingservices" className="app-menu__item">
              <span className="app-menu__label">Services</span>
            </Link>
          </li>
          <li>
            <Link  to="/garage" className="app-menu__item">
              <span className="app-menu__label">Garage</span>
            </Link>
          </li>
          <li>
            <Link to="/address" className="app-menu__item" >
              <span className="app-menu__label">Addresses</span>
            </Link>
          </li>
          <li>
            <Link to="/savecards" className="app-menu__item">
              <span className="app-menu__label">Saved Cards</span>
            </Link>
          </li>
          <li>
            <Link  to="/settings" className="app-menu__item">
              <span className="app-menu__label">Settings</span>
            </Link>
          </li>
        </ul>
        <ul className="">
          <li>
            <Link to="/loginregister" className="app-menu__item" >
              <span className="app-menu__label">Logout</span>
            </Link>
          </li>
        </ul>
            </aside>



        </div>);
}

export default SideBar;