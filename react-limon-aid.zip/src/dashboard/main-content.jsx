import React from "react";
import Modal from "react-bootstrap/Modal";
import card1 from "../images/card1.png";
import card2 from "../images/card2.png";
import card3 from "../images/card3.png";
import card4 from "../images/card4.png";
import VehicleInspectionReport from "../vehicle-inspection-report/vehicle-inspection-report";
import Garage from "../garage/garage";

const MainContnet = () => {
  const [type, setType] = React.useState("");
  const [cardNo, setCardNo] = React.useState(-1);

  return (
    <>
      <div className="header_top" data-toggle="">
        <div className="container-fluid mrgnLft">
          <div className="row">
            <div className="col-md-9 p-0">
              <div className="left-side_heading_home">
                <h1>Home</h1>
              </div>
            </div>
            <div className="col-md-3 text-right p-0">
              <div className="address-bar-wrapper">
                <p>
                  <span>
                    <i className="fa fa-map-marker" aria-hidden="true"></i>
                  </span>
                  &nbsp;New York City Hall, NYC
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="container mt-5">
        <div className="row">
          <div
            className="col-lg-5 col-md-12 col-sm-12 p-0 right-card"
            onClick={() => {
              setCardNo(1);
              setType("main");
            }}
          >
            <div className="content_card_wrapper">
              <div className="card-left-text">
                <div className="card-body-right">
                  <p className="card-title">Vehicle Inspection Report</p>
                  <p className="card-time">
                    <span>
                      <i className="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    45 mins
                  </p>
                  <p className="book-now-wrapper">
                    <span className="book-now">Book Now</span>
                    <span className="price float-right">$99</span>
                  </p>
                </div>
              </div>
              <div className="card-right-img">
                <img className="card-img img-fluid" src={card1} alt="Card" />
              </div>
            </div>
          </div>
          <div className="col-md-1"></div>
          <div
            className="col-lg-5 col-md-12 col-sm-12 p-0 right-card"
            onClick={() => {
              setCardNo(2);
              setType("main");
            }}
          >
            <div className="content_card_wrapper">
              <div className="card-left-text">
                <div className="card-body-right">
                  <p className="card-title">Vehicle Inspection Report</p>
                  <p className="card-time">
                    <span>
                      <i className="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    45 mins
                  </p>
                  <p className="book-now-wrapper">
                    <span className="book-now">Book Now</span>
                    <span className="price float-right">$99</span>
                  </p>
                </div>
              </div>
              <div className="card-right-img">
                <img className="card-img img-fluid" src={card2} alt="Card" />
              </div>
            </div>
          </div>
        </div>
        <div className="row row-padd">
          <div
            className="col-lg-5 col-md-12 col-sm-12 p-0 right-card"
            onClick={() => {
              setCardNo(3);
              setType("main");
            }}
          >
            <div className="content_card_wrapper">
              <div className="card-left-text">
                <div className="card-body-right">
                  <p className="card-title">Vehicle Inspection Report</p>
                  <p className="card-time">
                    <span>
                      <i className="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    45 mins
                  </p>
                  <p className="book-now-wrapper">
                    <span className="book-now">Book Now</span>
                    <span className="price float-right">$99</span>
                  </p>
                </div>
              </div>
              <div className="card-right-img">
                <img className="card-img img-fluid" src={card3} alt="Card" />
              </div>
            </div>
          </div>
          <div className="col-md-1"></div>
          <div className="col-lg-5 col-md-12 col-sm-12 p-0 right-card">
            <div className="content_card_wrapper">
              <div className="card-left-text">
                <div className="card-body-right">
                  <p className="card-title">Vehicle Inspection Report</p>
                  <p className="card-time">
                    <span>
                      <i className="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    45 mins
                  </p>
                  <p className="book-now-wrapper">
                    <span className="book-now">Book Now</span>
                    <span className="price float-right">$99</span>
                  </p>
                </div>
              </div>
              <div className="card-right-img">
                <img className="card-img img-fluid" src={card4} alt="Card" />
              </div>
            </div>
          </div>
        </div>
        <div className="row row-padd">
          <div className="col-lg-5 col-md-12 col-sm-12 p-0 right-card">
            <div className="content_card_wrapper">
              <div className="card-left-text">
                <div className="card-body-right">
                  <p className="card-title">Vehicle Inspection Report</p>
                  <p className="card-time">
                    <span>
                      <i className="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    45 mins
                  </p>
                  <p className="book-now-wrapper">
                    <span className="book-now">Book Now</span>
                    <span className="price float-right">$99</span>
                  </p>
                </div>
              </div>
              <div className="card-right-img">
                <img className="card-img img-fluid" src={card1} alt="Card" />
              </div>
            </div>
          </div>
          <div className="col-md-1"></div>
          <div className="col-lg-5 col-md-12 col-sm-12 p-0 right-card">
            <div className="content_card_wrapper">
              <div className="card-left-text">
                <div className="card-body-right">
                  <p className="card-title">Vehicle Inspection Report</p>
                  <p className="card-time">
                    <span>
                      <i className="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    45 mins
                  </p>
                  <p className="book-now-wrapper">
                    <span className="book-now">Book Now</span>
                    <span className="price float-right">$99</span>
                  </p>
                </div>
              </div>
              <div className="card-right-img">
                <img className="card-img img-fluid" src={card2} alt="Card" />
              </div>
            </div>
          </div>
        </div>
        <div className="row row-padd">
          <div className="col-lg-5 col-md-12 col-sm-12 p-0 right-card">
            <div className="content_card_wrapper">
              <div className="card-left-text">
                <div className="card-body-right">
                  <p className="card-title">Vehicle Inspection Report</p>
                  <p className="card-time">
                    <span>
                      <i className="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    45 mins
                  </p>
                  <p className="book-now-wrapper">
                    <span className="book-now">Book Now</span>
                    <span className="price float-right">$99</span>
                  </p>
                </div>
              </div>
              <div className="card-right-img">
                <img className="card-img img-fluid" src={card1} alt="Card" />
              </div>
            </div>
          </div>
          <div className="col-md-1"></div>
          <div className="col-lg-5 col-md-12 col-sm-12 p-0 right-card">
            <div className="content_card_wrapper">
              <div className="card-left-text">
                <div className="card-body-right">
                  <p className="card-title">Vehicle Inspection Report</p>
                  <p className="card-time">
                    <span>
                      <i className="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    45 mins
                  </p>
                  <p className="book-now-wrapper">
                    <span className="book-now">Book Now</span>
                    <span className="price float-right">$99</span>
                  </p>
                </div>
              </div>
              <div className="card-right-img">
                <img className="card-img img-fluid" src={card2} alt="Card" />
              </div>
            </div>
          </div>
        </div>
        <div className="row row-padd">
          <div className="col-lg-5 col-md-12 col-sm-12 p-0 right-card">
            <div className="content_card_wrapper">
              <div className="card-left-text">
                <div className="card-body-right">
                  <p className="card-title">Vehicle Inspection Report</p>
                  <p className="card-time">
                    <span>
                      <i className="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    45 mins
                  </p>
                  <p className="book-now-wrapper">
                    <span className="book-now">Book Now</span>
                    <span className="price float-right">$99</span>
                  </p>
                </div>
              </div>
              <div className="card-right-img">
                <img className="card-img img-fluid" src={card3} alt="Card" />
              </div>
            </div>
          </div>
          <div className="col-md-1"></div>
          <div className="col-lg-5 col-md-12 col-sm-12 p-0 right-card">
            <div className="content_card_wrapper">
              <div className="card-left-text">
                <div className="card-body-right">
                  <p className="card-title">Vehicle Inspection Report</p>
                  <p className="card-time">
                    <span>
                      <i className="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    45 mins
                  </p>
                  <p className="book-now-wrapper">
                    <span className="book-now">Book Now</span>
                    <span className="price float-right">$99</span>
                  </p>
                </div>
              </div>
              <div className="card-right-img">
                <img className="card-img img-fluid" src={card4} alt="Card" />
              </div>
            </div>
          </div>
        </div>
        <div className="row row-padd">
          <div className="col-lg-5 col-md-12 col-sm-12 p-0 right-card">
            <div className="content_card_wrapper">
              <div className="card-left-text">
                <div className="card-body-right">
                  <p className="card-title">Vehicle Inspection Report</p>
                  <p className="card-time">
                    <span>
                      <i className="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    45 mins
                  </p>
                  <p className="book-now-wrapper">
                    <span className="book-now">Book Now</span>
                    <span className="price float-right">$99</span>
                  </p>
                </div>
              </div>
              <div className="card-right-img">
                <img className="card-img img-fluid" src={card1} alt="Card" />
              </div>
            </div>
          </div>
          <div className="col-md-1"></div>
          <div className="col-lg-5 col-md-12 col-sm-12 p-0 right-card">
            <div className="content_card_wrapper">
              <div className="card-left-text">
                <div className="card-body-right">
                  <p className="card-title">Vehicle Inspection Report</p>
                  <p className="card-time">
                    <span>
                      <i className="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    45 mins
                  </p>
                  <p className="book-now-wrapper">
                    <span className="book-now">Book Now</span>
                    <span className="price float-right">$99</span>
                  </p>
                </div>
              </div>
              <div className="card-right-img">
                <img className="card-img img-fluid" src={card2} alt="Card" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <Modal show={!!type} onHide={() => setType("")}  centered >
        {type === "main" ?  <VehicleInspectionReport onSelect={() => setType("garage")} /> : type === "garage" ? <Garage /> : undefined}
      </Modal>
    </>
  );
};

export default MainContnet;
