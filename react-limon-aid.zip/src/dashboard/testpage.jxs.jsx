import React from "react";
import { Link } from "react-router-dom";
import "./sideBar.css";
import user from "../images/user.jpeg";
const SideBar = () => {
  return (
    <div className="app sidebar-mini">
      <header className=""></header>
      <div className="top_toggle_btn_wrapper">
        <a
          className="app-sidebar__toggle"
          href="#"
          data-toggle="sidebar"
          aria-label="Hide Sidebar"
        ></a>
      </div>
      <aside className="app-sidebar">
        <div className="user_wrapper text-center">
          <a href="app-menu__item">
            <img
              src={user}
              style={{ width: 120, height: 120, borderRadius: "100%" }}
            />
          </a>
          <div className="admin_name text-center pt-4 pb-4">
            <h3 className="text-center">John Doe</h3>
          </div>
        </div>
        <ul className="app-menu">
          <li>
            <Link to="/" className="app-menu__item">
              <span className="app-menu__label">Home</span>
            </Link>
          </li>
          <li>
            <Link to="/services" className="app-menu__item">
              <span className="app-menu__label">Services</span>
            </Link>
          </li>
          <li>
            <Link  to="/garage" className="app-menu__item">
              <span className="app-menu__label">Garage</span>
            </Link>
          </li>
          <li>
            <Link to="/address" className="app-menu__item" >
              <span className="app-menu__label">Addresses</span>
            </Link>
          </li>
          <li>
            <Link to="/savecards" className="app-menu__item">
              <span className="app-menu__label">Saved Cards</span>
            </Link>
          </li>
          <li>
            <Link  to="/settings" className="app-menu__item">
              <span className="app-menu__label">Settings</span>
            </Link>
          </li>
        </ul>
        <ul className="">
          <li>
            <Link to="/logout" className="app-menu__item" >
              <span className="app-menu__label">Logout</span>
            </Link>
          </li>
        </ul>
      </aside>
    </div>
  );
};

export default SideBar;
