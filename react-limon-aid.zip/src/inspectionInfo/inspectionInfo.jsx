import React from "react";
import card5 from "../images/card5.png";
import mastercard from "../images/mastercard.png";
import { Link } from "react-router-dom";

const InspectionInfo = () => {
  return (
    <div>
      <main className="">
        <div className="header_top" data-toggle="">
          <div className="container">
            <div className="row">
              <div className="col-md-9 p-0">
                <div className="left-side_heading_home">
                  <h1 className="Navs_headings">Inspection Info</h1>
                </div>
              </div>
              <div className="col-md-3 text-right p-0"></div>
            </div>
          </div>
        </div>

        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <div className="inspection-info-heading">
                <h3>Choose date, time and location</h3>
              </div>
            </div>
          </div>
          <div className="row mt-3">
            <div className="inspection-info-date">
              <form className="form-group">
                <div className="col-sm-6">
                  <label className="label-service-enter-vin" for="rg-from">
                    <small>Date</small>
                  </label>
                  <div className="form-group ">
                    <input
                      type="text"
                      id="rg-from"
                      name="rg-from"
                     
                      placeholder="22 June, 2020"
                      className="form-control"
                    />
                  </div>
                  <label className="label-service-enter-vin" for="rg-from">
                    <small>Time</small>
                  </label>
                  <div className="form-group ">
                    <input
                      type="text"
                      id="rg-from"
                      name="rg-from"
                     
                      placeholder="04:00 PM"
                      className="form-control"
                    />
                  </div>
                  <label className="label-service-enter-vin" for="rg-from">
                    <small>Location</small>
                  </label>
                  <div className="form-group ">
                    <input
                      type="text"
                      id="rg-from"
                      name="rg-from"
                     
                      placeholder="New York City Hall, NYC"
                      className="form-control"
                    />
                  </div>
                  <label className="label-service-enter-vin" for="rg-from">
                    <small>Any instructions to the driver?</small>
                  </label>
                  <div className="form-group ">
                    <input
                      type="text"
                      id="rg-from"
                      name="rg-from"
                     
                      placeholder="Car is parked behind my house in the alley"
                      className="form-control"
                    />
                  </div>
                </div>
              </form>
            </div>
            <div className="col-sm-6 maps">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d11880.492291371422!2d12.4922309!3d41.8902102!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x28f1c82e908503c4!2sColosseo!5e0!3m2!1sit!2sit!4v1524815927977"
                frameborder="0"
                style={{ width: "100%", height: "100%", border: "0" }}
                allowfullscreen
              ></iframe>
            </div>
          </div>
          <div className="row mt-5">
            <div className="col-sm-4 mb-4">
              <div className="card-inspection-info">
                <div className="top-plus">
                  <i className="fa fa-plus" aria-hidden="true"></i>
                </div>
                <img
                  src={card5}
                  className="img-fluid"
                  alt="card icons"
                  width="100%"
                />
                <div className="card-body">
                  <ul className="list-inline">
                    <li className="list-inline-item">
                      <h5 className="inspection-info-card-title">
                        Vehicle Inspection Report
                      </h5>
                      <p className="card-text">
                        <span>
                          <i className="fa fa-clock-o" aria-hidden="true"></i>
                        </span>{" "}
                        45 mins
                      </p>
                    </li>
                    <li className="list-inline-item inspection-info-service-prices ml-auto">
                      $99
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="col-sm-4 mb-4">
              <div className="card-inspection-info">
                <div className="top-plus">
                  <i className="fa fa-plus" aria-hidden="true"></i>
                </div>
                <img
                  src={card5}
                  className="img-fluid"
                  alt="card icons"
                  width="100%"
                />
                <div className="card-body">
                  <ul className="list-inline">
                    <li className="list-inline-item">
                      <h5 className="inspection-info-card-title">
                        Vehicle Inspection Report
                      </h5>
                      <p className="card-text">
                        <span>
                          <i className="fa fa-clock-o" aria-hidden="true"></i>
                        </span>{" "}
                        45 mins
                      </p>
                    </li>
                    <li className="list-inline-item inspection-info-service-prices ml-auto">
                      $99
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="col-sm-4 mb-4">
              <div className="next-service-btn2">
                <div className="text-right ml-auto infozMobile" align="right">
                  <Link to="/payment">
                    <button type="submit" className="btn next-btn2">
                      Next
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default InspectionInfo;
