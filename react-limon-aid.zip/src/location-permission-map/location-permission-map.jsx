import React from "react";
import { Link } from 'react-router-dom'
import verificationimg from "../images/phonevarificaiton.png";
import phone from "../images/phone.png";


const LocationPermissionMap = () => {
  return (
    <>
      <div>
        <Container></Container>
      </div>
    </>
  );
};

export default LocationPermissionMap;
