import React from "react";
import Modal from "react-bootstrap/Modal";
import Garage from "../garage/garage";


const ReportPdf = () => {
 
  return (
    <>
      <div>
      <div className="header_top" data-toggle="">
        <div className="container-fluid">
            <div className="row">
                <div className="col-lg-9 col-md-12">
                    <div className="left-side_heading_home">
                        <h1>Reports</h1>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

      <div className="container">
		<div className="row">
			<div className="col-md-6">
				<h3 className="heading">Vehicle Inspection Report</h3>
			</div>
			<div className="col-md-3"><div className="save-to-device"><button>Save to Device</button></div></div>
			<div className="col-md-3"><div className="reorder-green-device"><button>Re-order</button></div></div>
		</div>
		<div className="row mt-5">
			<div className="col-md-12">
				<div className="report-content">
					<p>
						Aliquam in bibendum mauris. Sed vitae erat vel velit blandit pharetra vitae nec ante. Cras at est augue. Cras ut interdum elit. Ut malesuada a urna sit amet blandit. Nullam nunc lorem, aliquam at eros laoreet, feugiat bibendum ligula. Aenean congue, massa id aliquet semper, ligula ante tristique nulla, quis posuere dui purus vel urna. Nullam varius, magna nec egestas convallis, orci ex tempus quam, id finibus arcu ipsum fringilla purus. Aenean dapibus suscipit eleifend. Aliquam vel ipsum eu lorem hendrerit iaculis vitae ut lorem. Suspendisse ullamcorper dolor faucibus sem auctor consequat. Ut luctus posuere auctor. Sed non molestie metus. Aliquam in bibendum mauris. Sed vitae erat vel velit blandit pharetra vitae nec ante. Cras at est augue. Cras ut interdum elit. Ut malesuada a urna sit amet blandit. Nullam nunc lorem, aliquam at eros laoreet, feugiat bibendum ligula. Aenean congue, massa id aliquet semper, ligula ante tristique nulla, quis posuere dui purus vel urna. Nullam varius, magna nec egestas convallis, orci ex tempus quam, id finibus arcu ipsum fringilla purus. Aenean dapibus suscipit eleifend. Aliquam vel ipsum eu lorem hendrerit iaculis vitae ut lorem. Suspendisse ullamcorper dolor faucibus sem auctor consequat. Ut luctus posuere auctor. Sed non molestie metus.
					</p>
				</div>
			</div>
		</div>
	</div>

      </div>
     
    </>
  );
};

export default ReportPdf;
