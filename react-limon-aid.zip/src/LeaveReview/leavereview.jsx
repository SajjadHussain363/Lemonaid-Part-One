import React from "react";
import { Link } from "react-router-dom";
import ReviewImg from "../images/reviewMan.png";

const LEAVEreview = () => {
  return (
    <>
      <div>
        <div className="container mt-5">
          <div className="row">
            <div className="col-md-4 mx-auto">
              <div className="leave_reviews_wrapper">
                <div className="leave-user_img">
                  <img src={ReviewImg} alt="ReviewImg" />
                </div>
                <h3 className="leave_reviews_heading text-center">John Doe</h3>
                <b className="review-sub-heading text-center">
                  Vehicle Inspection Specialist
                </b>
                <br /> <br />
                <h3 className="leave_reviews_heading text-center mt-5">
                  Leave a review
                </h3>
                <div className="star-rating text-center">
                  <span className="fa fa-star star-review-checked"></span>
                  <span className="fa fa-star star-review-checked"></span>
                  <span className="fa fa-star star-review-checked"></span>
                  <span className="fa fa-star star-review-checked"></span>
                  <span className="fa fa-star star-review-checked"></span>
                </div>
                <br />
                <textarea
                  className="form-control"
                  placeholder="Any comments"
                  rows="4"
                ></textarea>
                  <Link to="/">
                <button className="btn review-done-bnt text-white">Done</button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default LEAVEreview;
