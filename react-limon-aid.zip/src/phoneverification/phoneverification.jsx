import React from "react";
import { Link } from 'react-router-dom'
import verificationimg from "../images/phonevarificaiton.png";
import bottomimg from "../images/bottom.png";


const PhoneVerification = () => {
  return (
    <>
      <div className="phoneverification-wrapper">
        <div className="container">
            <div className="row mt-5">
                <div className="col-md-3 mx-auto">
                    <div className="phone-verification-wrapper">
                        <h3>Phone Verification</h3>
                    </div>
                <div className="phone-verification mt-5">
                    <img src={verificationimg} alt="phone" />
                </div>
                <div className="verification-numbers text-center mt-5">
                    <ul className="list-inline">
                    <li className="list-inline-item"></li>
                    <li className="list-inline-item"></li>
                    <li className="list-inline-item"></li>
                    <li className="list-inline-item"></li>
                </ul>
                </div>
                    <div className="lemon-wats-locaton-access mt-1">Didn't received the code yet?</div>
                    <div className="text-center">
                      <Link to="/locationpermission"  className="allow-button btn text-white">
                        Resend
                      </Link>
                    </div>  
                      
                </div>
            </div>
        </div>
        <div className="clearbothe"></div>
        <footer className="footer mt-auto">
            <div className="bottom-desing"><img src={bottomimg} alt="bottm" width="100%;" /></div>
        </footer>
       
      </div>
     
    </>
  );
};

export default PhoneVerification;
