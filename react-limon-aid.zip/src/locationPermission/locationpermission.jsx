import React from "react";
import { Link } from 'react-router-dom'
import verificationimg from "../images/phonevarificaiton.png";
import phone from "../images/phone.png";


const LocationPermission = () => {
  return (
    <>
      <div>
        <div className="container">
            <div className="row mt-5">
                <div className="col-md-3 mx-auto">
                    <div className="location-permission-wrapper">
                        <h3 >Location Permission</h3>
                    </div>
                    <div className="location-permission-icons mt-5">
                        <img src={phone} alt="phone" />
                    </div>
                    <div className="lemon-wats-locaton-access mt-5">LemonAid wants to access your location</div>
                    <div className="text-center"><button className="btn allow-button text-white">Allow</button></div>
                    <div className=" text-center"><button type="button" className="btn select-map">Select on map</button></div>
                </div>
            </div>
        </div>
      </div>
    </>
  );
};

export default LocationPermission;
