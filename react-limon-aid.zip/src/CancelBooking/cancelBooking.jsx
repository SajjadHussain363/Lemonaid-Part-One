import React from "react";
import Modal from "react-bootstrap/Modal";
import { Link } from "react-router-dom";
import reviewMan2 from "../images/reviewMan2.png";
//import LEAVEreview from '../LeaveReview/leavereviews'
import LEAVEreview from '../LeaveReview/leavereview'

const CANCELbooking = () => {
  const [type, setType] = React.useState("");
  const [cardNo, setCardNo] = React.useState(-1);

  return (
    <>
      <div>
        <div className="container mt-5">
        <div className="row">
          <div className="col-md-4 mx-auto">
            <div className="cancel-booking-wrapper">
              <div className="cancel-booking-inner">
                <div className="cancel-booking-top-img">
                  <img src={reviewMan2} alt="reviewMan2"/>
                  </div>
                  <p className="Accepted-cancel">Accepted</p>
                  <div className="cancel-booking-inner-dev mt-2">
                    <h3 className="cancel-booking-heading">John Doe</h3>
                    <p className="cancel-booking-paragraph">
                      Vehicle Inspection Specialist
                    </p>
                    <div className="cancel-booking-starRating">
                      <span>5.0</span>
                      <span className="fa fa-star star-cancel-checked"></span>
                      <span className="fa fa-star star-cancel-checked"></span>
                      <span className="fa fa-star star-cancel-checked"></span>
                      <span className="fa fa-star star-cancel-checked"></span>
                      <span className="fa fa-star star-cancel-checked"></span>
                    </div>
                    <div className="row">
                      <div className="col-md-7">
                        <ul className="list-inline cancel-booking-btn-wrapper">
                          <li className="list-inline-item">
                            <button  onClick={()=>{setType('main')}} className="btn cancel-booking-btn mt-4">
                              Cancel Booking
                            </button>
                          </li>
                        </ul>
                      </div>
                      <div className="col-md-5">
                        <ul className="list-inline cancel-booking-btn-wrapper">
                          <li className="list-inline-item booking-call">
                            <i className="fa fa-phone" aria-hidden="true"></i>
                          </li>
                          <li className="list-inline-item comments-message">
                            <i
                              className="fa fa-commenting-o"
                              aria-hidden="true"
                            ></i>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Modal show={!!type} onHide={() => setType("")}  centered >
        {
          type==="main"?<LEAVEreview />:null
        }
      </Modal>
    </>
  );
};

export default CANCELbooking;
