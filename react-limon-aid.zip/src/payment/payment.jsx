import React from "react";
import Modal from "react-bootstrap/Modal";
import { Link } from 'react-router-dom'
import visa1 from "../images/visa1.png";
import buket from "../images/buket.png";
import buketd from "../images/buketd.png";
import Paymentdonepopup from "../PaymentDoneCheck/paymentdonecheck";
import Garage from "../garage/garage";
import VehicleInsepctionReportPop from '../vehicle-inspection-report-popup/vehicle-inspection-report-popup'
import EditPayemtnRightSide from '../edit-payment-rightside/edit-payment-rightside'


const Payment = () => {
    const [type, setType] = React.useState("");
    const [cardNo, setCardNo] = React.useState(-1);
    // const [modal2, setModal2] = React.useState(false);
    const [sideBar, setSideBar] = React.useState(false);


    return (
        <>
            <div>
                <main className="">
                    <div className="header_top" data-toggle="">
                        <div className="container">
                            <div className="row">
                                <div className="col-lg-9 col-md-12 p-0">
                                    <h1 className="payments-heading_">Payment</h1>
                                    <h3 className="select_payment_Methods_heading">Select Payment Method</h3>
                                </div>
                                <div className="col-lg-3 p-0"></div>
                            </div>
                        </div>
                    </div>
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">

                            </div>
                        </div>

                        <div className="row mt-5">
                            <div className="col-md-5 mx-auto">
                                <div className="payments-card">
                                    <div className="tick-check"><i className="fa fa-check" aria-hidden="true"></i></div>
                                    <h3>John Doe</h3>
                                    <p> #### - #### - #### - 2134</p>
                                    <div className="visa_card text-right">
                                        <img src={visa1} alt="visa card" />
                                    </div>
                                </div>
                                <div className="edit-payment-methods mt-5">
                                    {/* <button onClick={() => { setModal2(true) }} className="btn">Edit Payment Method</button> */}
                                    <button onClick={() => { setSideBar((pre)=>!pre) }} className="btn">Edit Payment Method</button>

                                </div>
                                <div className="delete-report-btns mt-4">
                                    <a href="#">Vehicle Inspection Report &nbsp; &nbsp; &nbsp; <span><strong>$99</strong></span> <span>  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                        <img src={buketd} alt="buket" />
                                    </span>
                                    </a>
                                </div>
                                <div className="delete-report-btns mt-4">
                                    <a href="#">Vehicle Inspection Report &nbsp; &nbsp; &nbsp; <span><strong>$99</strong></span> <span>  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                        <img src={buketd} alt="buket" />
                                    </span>
                                    </a>
                                </div>

                                <div className="total_price mt-2"><p>$198</p></div>
                                <div className="payment-next-btn">

                                    <button onClick={() => { setType('main') }}>Next</button>

                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <Modal show={!!type} onHide={() => setType("")} centered >
                {type === "main" ? <Paymentdonepopup onSelect={() => setType("garage")} /> : type === "garage" ? <Garage /> : undefined}
            </Modal>
            {/* <Modal show={modal2} onHide={() => setModal2(false)}  centered >
      <VehicleInsepctionReportPop/>
      </Modal> */}
            {sideBar ? <EditPayemtnRightSide /> : null}
        </>
    );
};

export default Payment;
