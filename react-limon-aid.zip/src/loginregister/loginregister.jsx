import React, { useState } from 'react'
import { Link } from "react-router-dom";
import i3 from "../images/i3.png";
import i1 from "../images/i1.png";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';

  const LoginRegister = () => {
    const [pass, setPass] = useState(false)//hide-->false  show---->true
    const [conf, setConf] = useState(false)//hide-->false  show---->true
    const [confz, setConfz] = useState(false)//hide-->false  show---->true
    return(
    <div>
      <section className="login_content">
        <img className="bottom_design"  src={i3} alt="i3" />
        <div className="container">
          <div className="row">
            <div className="col-md-7">
              <div className="Logo-login-page mt-5">
                <img src={i1} alt="i1" />
              </div>
            </div>
            <div className="col-md-5 mt-5">
               <Tabs>
                <TabList>
                  <Tab>Login</Tab>
                  <Tab>Registration</Tab>
                </TabList>
            
                <TabPanel>
                <div id="login" role="tabpanel" aria-labelledby="home-tab" className="tab-pane fade px-4 py-5  show active">
              <div className="login-form-inner">
                <form>
                  <div className="form-group">
                    <label className="mb-0"><small>Email</small></label>
                    <input type="email" className="form-control h-0" id="formGroupExampleInput" placeholder="johndoe123@email.com" />
                  </div>
                  <div className="form-group">
                   <label className="mb-0"><small>Password</small></label>
                   <div className="input-group" id="show_hide_password">
                     <input id="password-field" type={pass ? "text" : "password"} className="form-control" name="password" placeholder="••••••••••••••" />
                        <span toggle="#password-field" className={pass ? "fa fa-eye-slash field-icon toggle-password"
                        : "fa fa-fw fa-eye field-icon toggle-password"} onClick={() => setPass(pre => !pre)} ></span>
                  </div>
                </div>
                <div className="remember">
                 <label className="custom-checkbox">Remember me
                   <input type="checkbox" />
                   <span className="checkmark"></span>
                 </label>
                 <a href="#" className="pull-right forget-password">Forgot Password?</a>
               </div>
               <div className="login_login_page">
               <Link to="/">
                 <button className="btn btn-login-form mt-3">Login</button>
                 </Link>
                 </div>
             </form>
           </div>
         </div>
        </TabPanel>
                <TabPanel>
                <div className="login-form-inner">
                <form>
                    <div className="row registration-form-inner-1st-row">
                        <div className="col">
                          <label className="mb-0"><small>First Name</small></label>
                          <input type="text" className="form-control" id="formGroupExampleInput" placeholder="John" />
                        </div>
                        <div className="col">
                          <label className="mb-0"><small>Last Name</small></label>
                          <input type="text" className="form-control" placeholder="Doe" />
                        </div>
                      </div>
                      <div className="form-group">
                        <label className="mb-0"><small>Email</small></label>
                        <input type="email" className="form-control" id="formGroupExampleInput" placeholder="johndoe123@email.com" />
                      </div>
                      <div className="form-group">
                        <label className="mb-0"><small>Phone Number</small></label>
                        <input type="text" className="form-control" id="formGroupExampleInput" placeholder="111-1235-4567" />
                      </div>
                      <div className="form-group">
                       <label className="mb-0"><small>Password</small></label>
                       <div className="input-group" id="show_hide_password">
                        <input id="password-field" type={conf ? "text" : "password"} className="form-control" name="password" placeholder="••••••••••••••" />
                          <span toggle="#password-field" className={conf ? "fa fa-eye-slash field-icon toggle-password"
                          : "fa fa-fw fa-eye field-icon toggle-password"} onClick={() => setConf(pre => !pre)} ></span>
                      </div>
                    </div>
                    <div className="form-group">
                       <label className="mb-0"><small>Confirm Password</small></label>
                       <div className="input-group" id="show_hide_confirm-password">
                       <input id="password-field" type={confz ? "text" : "password"} className="form-control" name="password" placeholder="••••••••••••••" />
                          <span toggle="#password-field" className={conf ? "fa fa-eye-slash field-icon toggle-password"
                          : "fa fa-fw fa-eye field-icon toggle-password"} onClick={() => setConfz(pre => !pre)} ></span>
                      </div>
                    </div>
                <div className="remember">
                 <label className="custom-checkbox">Accept terms and conditions
                   <input type="checkbox" />
                   <span className="checkmark"></span>
                 </label> 
               </div>
               <Link to="/verification">
               <button className="btn btn-login-form mt-3">Register</button>
               </Link>
             </form>
           </div>          
                </TabPanel>
              </Tabs>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default LoginRegister;
