import React from "react";
import SideBar from "./dashboard/sideBar";
import MainContnet from "./dashboard/main-content";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

import Services from "./services/services";
import Address from "./address/address";
import SaveCard from "./savecards/savecards";
import Settings from "./settings/settings";
import Garage from "./garage/garage";
import LoginRegister from "./loginregister/loginregister";
import InspectionInfo from "./inspectionInfo/inspectionInfo";
import Payment from "./payment/payment";
import Paymentdonepopup from "./PaymentDoneCheck/paymentdonecheck";
import CANCELbooking from "./CancelBooking/cancelBooking";
import "../node_modules/bootstrap/dist/css/bootstrap.css";
import PhoneVerification from "./phoneverification/phoneverification"
import LocationPermission from "./locationPermission/locationpermission"
import UpComingServices from './ucoming-services/upcomingServices'
import "./App.css";
function App() {
  return (
    <>
      <Router>
        <SideBar />

        <Switch>
          <Route exact path="/">
            <main className="app-content">
              <MainContnet />
            </main>
          </Route>
          <Route exact path="/review">
            <main className="app-content">
              <MainContnet />
              <CANCELbooking />
            </main>
          </Route>
          <Route path="/upcomingservices">
            <main className="app-content">
              <UpComingServices />
            </main>
          </Route>
          <Route path="/garage">
            <main className="app-content">
              <Garage />
            </main>
          </Route>
          <Route path="/services">
            <main className="app-content">
              <Services />
            </main>
          </Route>
          <Route path="/address">
            <main className="app-content">
              <Address />
            </main>
          </Route>
          <Route path="/savecards">
            <main className="app-content">
              <SaveCard />
            </main>
          </Route>
          <Route path="/settings">
            <main className="app-content">
              <Settings />
            </main>
          </Route>
          <Route path="/loginregister">
            <main className="app-content">
              <LoginRegister />
            </main>
          </Route>
          <Route path="/inspectionInfo">
            <main className="app-content">
              <InspectionInfo />
            </main>
          </Route>
          <Route path="/payment">
            <main className="app-content">
              <Payment />
            </main>
          </Route>
          <Route path="/PaymentDoneCheck">
            <main className="app-content">
              <Paymentdonepopup />
            </main>
          </Route>
          <Route path="/verification">
            <main className="app-content">
              <PhoneVerification />
            </main>
          </Route>
          <Route path="/locationpermission">
            <main className="app-content">
              <LocationPermission />
            </main>
          </Route>
        </Switch>
      </Router>
    </>
  );
}

export default App;
