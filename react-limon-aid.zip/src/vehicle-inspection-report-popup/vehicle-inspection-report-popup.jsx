import React from "react";
import Modal from "react-bootstrap/Modal";
import Garage from "../garage/garage";


const VehicleInsepctionReportPop = () => {
 
  return (
    <>
      <div>
      <div className="container mt-5">
 		<div className="row">
 			<div className="col-md-8  mx-auto">
 				<div className="vehicle-inspection-report-wrapper">
 					<h3>Vehicle Inspection Report</h3>

 					<div className="row">
 						<div className="col-sm-6">
 							<ul className="list-inline Inspection-left-ul">
 								<li className="list-inline-item Inspection-date-ist">
 									<label><small>Date</small></label>
 									<p>22 June, 2020</p>
 								</li>
 								<li className="list-inline-item Inspection-time-ist">
 									<label><small>Time</small></label>
 									<p>04:00 PM</p>
 								</li>
 								<div className="mt-1">
 									<label><small>Location</small></label>
 									<p>W 3rd City, New York City</p>
 								</div>
 							</ul>
 						</div>
 						<div className="col-sm-6">
 							<ul className="list-inline">
 								<li className="list-inline-item Inspection-date-ist">
 									<label><small>Make</small></label>
 									<p>Toyota</p>
 								</li>
 								<li className="list-inline-item Inspection-time-ist">
 									<label><small>Model</small></label>
 									<p>Camry 2.4</p>
 								</li>
 								<li className="list-inline-item Inspection-time-ist">
 									<label><small>Year</small></label>
 									<p>2018</p>
 								</li>
 								<li className="list-inline-item Inspection-time-ist">
 									<label><small>Miles</small></label>
 									<p>60,000</p>
 								</li>
 							</ul>
 						</div>
 						<div className="cancel-booking-btn mt-4">
 							<button className="btn">Cancel Booking</button>
 						</div>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
      </div>
     
    </>
  );
};

export default VehicleInsepctionReportPop;
